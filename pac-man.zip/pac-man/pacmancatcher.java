import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;
/**
 * Write a description of class pacmancatcher here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class pacmancatcher extends Actor
{
    public Object returnIntersectingBalls(){
        return this.getOneIntersectingObject(ball.class);
    }
    public Object returnIntersectingFruit(){
        return this.getOneIntersectingObject(fruit.class);
    }
    public Object returnIntersectingRedGhost(){
        return this.getOneIntersectingObject(redGhost.class);
    }
    public Object returnIntersectingPinkGhost(){
        return this.getOneIntersectingObject(pinkGhost.class);
    }
    public Object returnIntersectingBlueGhost(){
        return this.getOneIntersectingObject(blueGhost.class);
    }
    public Object returnIntersectingOrangeGhost(){
        return this.getOneIntersectingObject(orangeGhost.class);
    }
    public Object returnIntersectingBigBall(){
        return this.getOneIntersectingObject(bigball.class);
    }  
}
