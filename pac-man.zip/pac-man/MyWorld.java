import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;
/**
 * “Pac-Man is an electronic video game in which a player attempts to guide a 
 * voracious, blob-shaped character through a maze while eluding attacks from 
 * opposing images which it may in turn devour. It is also the name of the blob-shaped 
 * character itself”
 * 
 * @author makenna
 * @version 1
 */
public class MyWorld extends World
{
    PacMan man = new PacMan();
    ArrayList<ball> balls = new ArrayList<ball>(); //ball
    ArrayList<wall> walls = new ArrayList<wall>(); //wall
    ArrayList<smallwall> swall = new ArrayList<smallwall>(); //small wall
    teleportWall teleportwall1 = new teleportWall(); //teleport wall
    teleportWall teleportwall2 = new teleportWall();
    
    int score = 0;
    //Constructor for objects of class MyWorld.

    public MyWorld() //myWorld holds the background, the transparent walls (creating the maze), 
                    //and the balls that pacman will eat
    {    
        
        super(600, 450, 1); 
        Greenfoot.playSound("pacman_beginning.wav"); //plays sound when game is loaded
        //Y-axis 100 -> 200
        //X-axis 200 -> 300
        
        //Ghosts
        addObject(man.getredGhost(), 267, 200);
        addObject(man.getpinkGhost(), 290, 200);
        addObject(man.getblueGhost(), 313, 200);
        addObject(man.getorangeGhost(), 336, 200);
        //end ghosts
        
        //pacman boundaries
        addObject(man,117,200);
        addObject(man.getUpperBound(),118,186);
        addObject(man.getLowerBound(),118,214);
        addObject(man.getRightBound(),132,200);
        addObject(man.getLeftBound(),102,200);
        man.getUpperBound().getImage().setTransparency(0); //transparent boundary 
        man.getLowerBound().getImage().setTransparency(0); 
        man.getLeftBound().getImage().setTransparency(0); 
        man.getRightBound().getImage().setTransparency(0);
        //end boundaries   
        
        //score 
        addObject(man.getscore1(),68,75);
        addObject(man.getscore10(),52,75);
        addObject(man.getscore100(),36,75);
        addObject(man.getscore1000(),20,75);
        addObject(man.getHighScore1000(),529,75);
        addObject(man.getHighScore100(),547,75);
        addObject(man.getHighScore10(),565,75);
        addObject(man.getHighScore1(),582,75);
        man.setHighScore(man.getHighScore());
        //end score 
        
        //add 3 lives 
        addObject(man.getLife1(),13,104);
        addObject(man.getLife2(),39,104);
        addObject(man.getLife3(),66,104);
        //end lives
        
        //fruit 
        addObject(man.getFruit1(),235,115);
        addObject(man.getFruit2(),364,354);
        //end add fruit
        
        //add big balls
        addObject(man.getBigBall1(),113,78);
        addObject(man.getBigBall2(),113,280);
        addObject(man.getBigBall3(),486,78);
        addObject(man.getBigBall4(),486,280);
        
        //pacman catcher & transparency
        man.getPacManCatcher().getImage().setTransparency(0);
        addObject(man.getPacManCatcher(),117,200);
        
        
        //placing the balls start
        int j = 0;
        for(int i = 0; i<300; i++){
            balls.add(new ball());
        }//end for
        for(int i = 359; i > 14; i -= 15){ //fi
           addObject(balls.get(j), 414, i);
            j++;
        }//end fori=359 north/south far right
        for(int i = 340; i > 39; i -= 15){ //fi
            addObject(balls.get(j), 186, i);
            //addObject(balls.get(j), 215, 200);
            j++;
        }//end fori=359 north/south second row from left
        for(int i = 169;i > 108;i -= 15){//fi
             addObject(balls.get(j),i,359);
             j++;
        }//end fori=169 east/west 2nd row from bottom - far left
        for(int i=201; i < 401; i += 15){ //fi
             addObject(balls.get(j),i,318);
             j++;
            }//end fori=201 east/west 3rd row from bottom - middle
        for(int i=204; i < 401; i += 15){ //fi
            addObject(balls.get(j), i, 81);
            j++;
        }//endi = 204 east/west 2nd row - middle part
        for(int i = 324; i < 485; i +=15){ //fi
            addObject(balls.get(j), i, 29);
            j++;
        }//end fori=324 east/west top row - right side
        for(int i = 120; i < 284; i +=15){ //fi
            addObject(balls.get(j), i, 29);
            j++;
        }//end fori=114 east/west top row - left side
        for(int i = 120; i < 495; i+=15){ //fi
            addObject(balls.get(j), i, 397);
            j++;
        }//end fori=113 east/west (bottom row)
        /*for(int i=429;i<504;i+=15)
        {
            addObject(balls.get(j),i,29);
               j++;
        }*/
        for(int i = 163; i < 277; i += 15){ //fi
             addObject(balls.get(j),233,i);
             j++;
             addObject(balls.get(j),366,i);
             j++;
        }//end fori=157 north/south (next to ghost box)
        for(int i = 247; i <358; i +=15){//fi
        addObject(balls.get(j), i, 158);
        j++;
        }//end fori=250 above ghost box 
        for(int i = 247; i <358; i +=15){//if
        addObject(balls.get(j), i, 240);
        j++;
        }//end fori=247 e/w below ghost box
        for(int i = 199; i < 285; i += 15) { //fi
             addObject(balls.get(j),i,279);
             j++;
        }//end fori=199 east/west 4th row from bottom - left side
        for(int i = 324; i < 410; i += 15){ //fi
             addObject(balls.get(j),i,279);
             j++;
        } //end fori=324 east/west 4th row from bottom - right side
        for(int i = 428; i < 492; i += 15){ //fi
             addObject(balls.get(j),i,360);
             j++;
        } //end fori=428 east/west 2nd row from bottom right side
        
        for(int i = 124; i < 181; i += 15){ //fi
             addObject(balls.get(j),i,200);
             j++;
        }//end fori=124, east/west (first entrance)
        for(int i = 431; i < 491; i += 15){ //fi
             addObject(balls.get(j),i,200);
             j++;
        }//end fori=431, east/west (second entrance)
         for(int i = 124; i < 181; i += 15){ //fi
             addObject(balls.get(j),i,279);//fourth row from bottom
             j++;
              addObject(balls.get(j),i,80);//second row from top
             j++;
        }//end fori=124, east/west (left side)
        for(int i = 118; i < 180; i += 15) {//fi
             addObject(balls.get(j),i,123);
             j++;
        }//end fori=109, east/west third row from top, left side
        for(int i = 430; i < 478; i += 15){ //fi
             addObject(balls.get(j),i,80);//second row from top
             j++;
             addObject(balls.get(j),i,122);//third row from top
             j++;
             addObject(balls.get(j),i,279);//third row from bottom
             j++;
        } //end fori=430, east/west far right
        for(int i = 240; i < 285; i += 15){ //fi
             addObject(balls.get(j),i,357);
             j++;
        } //end fori=230, east/west 2nd row from bottom - middle left
        for(int i = 327; i < 350; i += 15){ //fi
             addObject(balls.get(j),i,357);
             j++;
        }//end fori=327, east/west 2nd row from bottom - middle right (by cherry)
        addObject(balls.get(j),202,200);//east/west next to entrance
             j++;
        addObject(balls.get(j),220,200);//east/west next to entrance
             j++;
        addObject(balls.get(j),380,200);//east/west next to second entrance
             j++;    
        addObject(balls.get(j),400,200);//east/west next to second entrance
             j++;
        for(int i = 60; i > 53; i -= 15){//fi
        addObject(balls.get(j),488,i);
             j++;
            }//end fori=60 north/south far right, top (above big ball)
        for(int i = 114; i > 87; i -= 15){//fi
        addObject(balls.get(j),488,i);
             j++;
            }//end fori=117 north/south far right, top (below big ball)   
        addObject(balls.get(j), 488, 46); //far right, top
             j++;
        for(int i = 318; i > 289; i -= 15){//fi
        addObject(balls.get(j),488,i);
             j++;
        }//end fori=325 n/s far right bottom (below big ball)
        addObject(balls.get(j), 488, 378);//far right, bottom
             j++;
        for(int i = 310; i > 290; i -= 15){ //fi
           addObject(balls.get(j), 110, i);
            j++;
        }//end fori=310 n/s far left, bottom (below big ball)
        addObject(balls.get(j), 110, 378); //far left, bottom
            j++;
        for(int i = 60; i > 35; i -= 15){ //fi
            addObject(balls.get(j), 109, i);
            j++;
        }//end fori=60, far left, top (above big ball)
        for(int i = 110; i > 90; i -= 15){ //fi
            addObject(balls.get(j), 109, i);
            j++;
        }//end fori=110, far left, top (below big ball)
        addObject(balls.get(j), 275, 376);//bottomish-middleish
        j++;
        addObject(balls.get(j), 327, 376);//bottomish-middleish
        j++;
        addObject(balls.get(j), 275, 300);//bottomish-middleish 
        j++;
        addObject(balls.get(j), 322, 300);//bottomish-middleish
        j++;
        addObject(balls.get(j), 231, 337);//bottom middleish
        j++;
        addObject(balls.get(j), 370, 337);
        j++;
        addObject(balls.get(j), 279, 42);
        j++;
        addObject(balls.get(j), 279, 55);
        j++;
        addObject(balls.get(j), 279, 68);
        for(int i = 85; i > 32; i -= 15){//fi
            addObject(balls.get(j), 324, i);
            j++;
        }//very middle right top n/s
        for(int i = 145; i > 120; i -= 15){ //fi
            addObject(balls.get(j), 322, i);
            j++;
        }//end fori=145 n/s over ghost gate right 4th row
        for(int i = 145; i > 115; i -= 15){//fi
        addObject(balls.get(j), 277, i);
        j++;
        }//end fori=145 n/s over ghost gate left 3rd row
        for(int i = 260; i < 287; i += 15){//fi
        addObject(balls.get(j), i, 118);
        j++;
        }//end fori=230 e/w 3rd row (by top cherry)
        for(int i = 323; i < 380; i += 15){//fi
        addObject(balls.get(j), i, 118);
        j++;
        }//endfori=323 e/w 3rd row right
        addObject(balls.get(j), 367, 100);
        j++;
        addObject(balls.get(j), 230, 100);
        j++;
        for(int i = 127; i < 150; i += 15){//fi
        addObject(balls.get(j), i, 322);
        j++;
        }//end fori=120 left bottom
        addObject(balls.get(j), 140, 340);
        j++;
        for(int i = 455; i < 483; i += 14){//fi
            addObject(balls.get(j), i, 322);
            j++;
        }//end fori=455 right bottom
        addObject(balls.get(j), 455, 340);
        j++;
        //addObject(balls.get(j), 111, 393);
        //j++;
        //end balls
        
        //walls
        for(int i = 0; i < 100; i++){
            walls.add(new wall());
            walls.get(i).getImage().setTransparency(0);
        }
        //horizontal
        addObject(walls.get(0), 125, 214);//entrance bottom
        addObject(walls.get(1), 125, 262);
        addObject(walls.get(2), 125, 183);//entrance top
        addObject(walls.get(3), 125, 136);
        addObject(walls.get(4), 125, 12);//very top left
        addObject(walls.get(5), 125, 412);//very bottom left
        addObject(walls.get(6), 190, 412);
        addObject(walls.get(7), 250, 412);
        addObject(walls.get(8), 310, 412);
        addObject(walls.get(29), 377, 412);
        addObject(walls.get(9), 440, 412);
        addObject(walls.get(30), 470, 412);
        addObject(walls.get(10), 473, 214);//second entrance bottom
        addObject(walls.get(11), 473, 183);//second entrance top 
        addObject(walls.get(12), 473, 136);
        addObject(walls.get(13), 473, 262);
        addObject(walls.get(14), 465, 12);//very top right
        addObject(walls.get(15), 185, 12);
        addObject(walls.get(31), 255, 12);
        addObject(walls.get(16), 334, 12);
        addObject(walls.get(17), 400, 12);
        addObject(walls.get(18), 284, 98); //middle top T
        addObject(walls.get(19), 284, 254);
        addObject(walls.get(20), 284, 334);
        addObject(walls.get(21), 165, 372);
        addObject(walls.get(22), 165, 381);
        addObject(walls.get(23), 225, 381);
        addObject(walls.get(24), 378, 381);
        addObject(walls.get(25), 438, 381);
        addObject(walls.get(26), 438, 372);
        addObject(walls.get(27), 278, 223);
        addObject(walls.get(28), 318, 223);
        //end walls
        
        //start large vertical walls
        for(int i=77;i<100;i++)
        {
            walls.get(i).turn(-90);
        }
        addObject(walls.get(77), 504,100);//far right wall 504
        addObject(walls.get(78), 504,45);
        addObject(walls.get(79), 96,100);//far left wall 96
        addObject(walls.get(80), 96,45);
        addObject(walls.get(81), 96,300);
        addObject(walls.get(82), 96,370);
        addObject(walls.get(83), 504,300);
        addObject(walls.get(84), 504,370);
        addObject(walls.get(85), 205,150);
        addObject(walls.get(86), 205,132);
        addObject(walls.get(87), 400,132);
        addObject(walls.get(88), 400,150);
        //end large vertical walls 
        
        //start small walls
        for(int i = 0; i < 100; i++){
            swall.add(new smallwall());
            swall.get(i).getImage().setTransparency(0);
        }
        addObject(swall.get(1), 149, 44);//left side
        addObject(swall.get(2), 149, 64);//first square from left
        addObject(swall.get(3), 149, 94);
        addObject(swall.get(4), 149, 104);
        addObject(swall.get(5), 149, 294);
        addObject(swall.get(6), 143, 302);
        addObject(swall.get(7), 220, 44);
        addObject(swall.get(8), 220, 66);//second square from the left 
        addObject(swall.get(9), 245, 44);
        addObject(swall.get(10), 245, 66);
        addObject(swall.get(11), 238, 142);
        addObject(swall.get(12), 242, 138);
        addObject(swall.get(13), 242, 298);
        addObject(swall.get(14), 220, 300);
        addObject(swall.get(15), 242, 293);
        addObject(swall.get(16), 220, 293);
        addObject(swall.get(17), 242, 373); //second row from bottom
        addObject(swall.get(18), 360, 64);
        addObject(swall.get(19), 380, 64);
        addObject(swall.get(20), 360, 44);
        addObject(swall.get(21), 380, 44);
        addObject(swall.get(22), 450, 44);//right side
        addObject(swall.get(23), 450, 64);
        addObject(swall.get(24), 450, 94);
        addObject(swall.get(25), 450, 104);
        addObject(swall.get(26), 450, 294);
        addObject(swall.get(27), 458, 302);
        addObject(swall.get(28), 355, 294);
        addObject(swall.get(29), 380, 294);
        addObject(swall.get(30), 355, 303);
        addObject(swall.get(31), 380, 303);
        addObject(swall.get(32), 355, 138);
        addObject(swall.get(33), 335, 97);//middle top T
        addObject(swall.get(34), 355, 144);
        addObject(swall.get(35), 330, 254);
        addObject(swall.get(36), 330, 261);
        addObject(swall.get(37), 271, 261); //second T from bottom
        addObject(swall.get(38), 330, 334);
        addObject(swall.get(39), 330, 342);
        addObject(swall.get(40), 271, 340);//very bottom T
        addObject(swall.get(41), 271, 103); //middle top T
        addObject(swall.get(42), 330, 103);
        addObject(swall.get(43), 358, 373);
        addObject(swall.get(44), 490, 337);
        //addObject(swall.get(45), 490, 332);
        //addObject(swall.get(46), 110, 332);//sticking out from far left wall on bottom
        addObject(swall.get(47), 110, 337);//sticking out from far left wall on bottom
        addObject(swall.get(48), 265, 175);
        addObject(swall.get(49), 337, 175);
        //end small walls
        
        //start small vertical walls 
        for(int i=50;i<100;i++)
        {
            swall.get(i).turn(-90);
        }
        addObject(swall.get(50), 170, 317);
        addObject(swall.get(51), 160, 320);//bottom left
        addObject(swall.get(52), 430, 320); //bottom right
        addObject(swall.get(53), 440, 320);
        addObject(swall.get(54), 214, 350);//upside down T bottom left
        addObject(swall.get(55), 205, 350);
        addObject(swall.get(56), 295, 364);
        addObject(swall.get(57), 306, 364);
        addObject(swall.get(58), 397, 350);
        addObject(swall.get(59), 385, 350);
        addObject(swall.get(60), 170, 248);
        addObject(swall.get(61), 430, 230);//vertical bottom of 2nd entrance
        addObject(swall.get(62), 430, 248);
        addObject(swall.get(63), 204, 230);
        addObject(swall.get(64), 204, 248);
        addObject(swall.get(65), 215, 230);//left of ghost box
        addObject(swall.get(66), 215, 248);
        addObject(swall.get(67), 400, 230);
        addObject(swall.get(68), 400, 248);
        addObject(swall.get(69), 385, 230);
        addObject(swall.get(70), 385, 248);
        addObject(swall.get(71), 295, 286);
        addObject(swall.get(72), 308, 286);
        addObject(swall.get(73), 250, 200);
        addObject(swall.get(74), 353, 200);
        //addObject(swall.get(77), 130, 55);//top left corner box
        //addObject(swall.get(78), 170, 55);
        //addObject(swall.get(79), 200, 55);
        //addObject(swall.get(80), 260, 55);
        //addObject(swall.get(81), 340, 55);
        //addObject(swall.get(82), 400, 55);
        //addObject(swall.get(87), 430, 55);
        //addObject(swall.get(88), 472, 55);
        addObject(swall.get(83), 387, 114);//right top sideways T
        addObject(swall.get(84), 213, 114);//left top sideways T
        addObject(swall.get(85), 213, 165);
        addObject(swall.get(86), 387, 165);//right top sideways T
        addObject(swall.get(89), 298, 47); //sticking out from top hor wall
        addObject(swall.get(90), 298, 31);
        addObject(swall.get(91), 306, 47);
        addObject(swall.get(92), 306, 31);
        addObject(swall.get(93), 297, 127);
        addObject(swall.get(94), 305, 127);
        addObject(swall.get(95), 170, 168);//vertical top of entrance
        addObject(swall.get(96), 170, 150);
        addObject(swall.get(97), 430, 168);//vertical top of 2nd entrance
        addObject(swall.get(98), 430, 150);
        addObject(swall.get(99), 170, 230);//vertical bottom of entrance
        //end small vertical walls
        
        //teleport walls
        teleportwall1.setRotation(-90); //vertical
        teleportwall2.setRotation(-90); //vertical
        addObject(teleportwall1,96,200); //front entrance
        addObject(teleportwall2,507,198); //second entrance
        teleportwall1.getImage().setTransparency(0); //transparent
        teleportwall2.getImage().setTransparency(0); //transparent
        //end teleport walls
        
    }
    public PacMan getPacMan()
    {
        return man;
    }
    
    
    
    
    
    
    
}
