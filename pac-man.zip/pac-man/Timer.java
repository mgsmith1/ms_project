import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Timer here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Timer extends Actor
{
    int count=0;
    public void startTimer(){
        count++;
    }
    public void stopTimer(){
        count=0;
    }
    public int getTime(){
        return count;
    }
}
        

