import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * “Pac-Man is an electronic video game in which a player attempts to guide a 
 * voracious, blob-shaped character through a maze while eluding attacks from 
 * opposing images which it may in turn devour. It is also the name of the blob-shaped 
 * character itself”
 * 
 * @author makenna
 * @version 1
 */
public class PacMan extends Actor
{
    //ghosts & ghost respawning
    redGhost red = new redGhost();
    pinkGhost pink = new pinkGhost();
    blueGhost blue = new blueGhost();
    orangeGhost orange = new orangeGhost();
    Timer ghostTimer = new Timer();
    Timer redGhostRespawnTimer = new Timer();
    Timer pinkGhostRespawnTimer = new Timer();
    Timer blueGhostRespawnTimer = new Timer();
    Timer orangeGhostRespawnTimer = new Timer();
    
    //boundary around pacman
    boundary e = new boundary();
    boundary f = new boundary();
    boundary g = new boundary();
    boundary h = new boundary();
    
    pacmancatcher catcher = new pacmancatcher();
   
    //3 lives
    life life1 = new life();
    life life2 = new life();
    life life3 = new life();
    int livesLeft=3;
    
    //4 big balls, ball count, balltimer
    //ball timer for when the big ball is eaten 
    int ballCount=0;
    bigball bigball1 = new bigball();
    bigball bigball2 = new bigball();
    bigball bigball3 = new bigball();
    bigball bigball4 = new bigball();
    Timer ballSoundTimer = new Timer();
    boolean ballTimerStarted=false;
    
    //score
    static int highScore;
    score1 score1 = new score1();
    score10 score10 = new score10();
    score100 score100 = new score100();
    score1000 score1000 = new score1000();
    score1 highScore1 = new score1();
    score10 highScore10 = new score10();
    score100 highScore100 = new score100();
    score1000 highScore1000 = new score1000();
    
    //2 fruit
    fruit fruit1 = new fruit();
    fruit fruit2 = new fruit();
    
    Timer chompTimer = new Timer();
    boolean gameOver=false;
    int gameWinCount=0;
    int teleportCount=0;
    int PacManImage = 0;
    boolean powerUp=false;
    
    public void act() 
    {
        if(PacManImage==0){ //change image 
            this.setImage("pacman3.jpg");
        }
        if(PacManImage==1){ //change image
            this.setImage("pacman2.gif");
        }
        if(PacManImage==2){ //change image 
            this.setImage("pacman4.gif");
        }
        
        //movements
        if(Greenfoot.isKeyDown("Right")){ //right key
           if(!g.getIsTouching()){
               if(PacManImage==2){
                   PacManImage=0; //switch image from image2 -> image0 when key is pressed
                }
                else{
                    PacManImage++;
                }
                catcher.setRotation(0);
                catcher.move(2);
                e.setRotation(0);
                e.move(2);
                f.setRotation(0);
                f.move(2);
                g.setRotation(0);
                g.move(2);
                h.setRotation(0);
                h.move(2);
                setRotation(0);
                move(2);
           }
       }
        if(Greenfoot.isKeyDown("Left")){ //left key
           if(!h.getIsTouching()){
               if(PacManImage==2){//switch image from image2 -> image0 when key is pressed
                   PacManImage=0;
                }
                else{
                    PacManImage++;
                }
               catcher.setRotation(180);
               catcher.move(2);
               e.setRotation(180);
               e.move(2);
               f.setRotation(180);
               f.move(2);
               g.setRotation(180);
               g.move(2);
               h.setRotation(180);
               h.move(2);
               setRotation(180);
               move(2);
            }
       }
       if(Greenfoot.isKeyDown("Up")){ //up key
           if(!e.getIsTouching()){
               if(PacManImage==2){//switch image from image2 -> image0 when key is pressed
                   PacManImage=0;
                }
                else{
                    PacManImage++;
                }
               catcher.setRotation(270);
               catcher.move(2);
               e.setRotation(270);
               e.move(2);
               f.setRotation(270);
               f.move(2);
               g.setRotation(270);
               g.move(2);
               h.setRotation(270);
               h.move(2);
               setRotation(270);
               move(2);
           }
        }
        if(Greenfoot.isKeyDown("Down")){ //down key 
           if(!f.getIsTouching()){
               if(PacManImage==2){
                   PacManImage=0;
                }
                else{
                    PacManImage++;
                }
               catcher.setRotation(90);
               catcher.move(2);
               e.setRotation(90);
               e.move(2);
               f.setRotation(90);
               f.move(2);
               g.setRotation(90);
               g.move(2);
               h.setRotation(90);
               h.move(2);
               setRotation(90); 
               move(2);
           }
       }
       //end movements
       
       //lives
       if(livesLeft==0){ //if the lives left = 0 then the game is over and the gameover object is displayed
            gameOver=true;
            getImage().setTransparency(0);
            if(ballCount>highScore){
            highScore=ballCount;
            setHighScore(highScore);
            }
          getWorld().addObject(new gameover(),300,300);
        }
       //end lives
           
       //game win
       //if the gamewincount = 259 then the game is over but the player has won. The youwin will be displayed
       if(gameWinCount ==259){
           gameOver=true;
           if(ballCount>highScore){
            highScore=ballCount;
            setHighScore(highScore);
            }
            getImage().setTransparency(0);
            getWorld().addObject(new youwin(),300,300);
        }
        //end game win
        
        //ghost respawn timer 
        //if pacman eats a big ball and is able to eat the ghosts, after they are eaten 
        //- they respawn 
        //I found help with this code on the Greenfoot website
        if(redGhostRespawnTimer.getTime()>0){
            redGhostRespawnTimer.startTimer();
            if(redGhostRespawnTimer.getTime()==300){
               red=new redGhost();
               getWorld().addObject(red,267,200); 
               redGhostRespawnTimer.stopTimer();
            }
       }
       if(pinkGhostRespawnTimer.getTime()>0){
            pinkGhostRespawnTimer.startTimer();
            if(pinkGhostRespawnTimer.getTime()==300){
               pink=new pinkGhost();
               getWorld().addObject(pink,290,200);
               pinkGhostRespawnTimer.stopTimer();
            }
       }
       if(blueGhostRespawnTimer.getTime()>0){
            blueGhostRespawnTimer.startTimer();
            if(blueGhostRespawnTimer.getTime()==300){
               blue=new blueGhost();
               getWorld().addObject(blue,313,200);  
               blueGhostRespawnTimer.stopTimer();
            }
       }
       if(orangeGhostRespawnTimer.getTime()>0){
            orangeGhostRespawnTimer.startTimer();
            if(orangeGhostRespawnTimer.getTime()==300){
               orange=new orangeGhost();
               getWorld().addObject(orange,336,200);   
               orangeGhostRespawnTimer.stopTimer();
            }
       }
       //end ghost timer 
       
       setHighScore(highScore);
       
       //isTouching teleport wall
       //teleport walls are placed at the entrances 
       if(this.isTouching(teleportWall.class)){
           teleportCount++;
           if(teleportCount%2==1){
               this.setLocation(497,200);
               catcher.setLocation(497,200);
               e.setLocation(498,186);
               f.setLocation(498,214);
               g.setLocation(511,200);
               h.setLocation(484,200);
            }
           if(teleportCount%2==0){
                this.setLocation(117,200);
                catcher.setLocation(117,200);
                e.setLocation(118,186);
                f.setLocation(118,214);
                g.setLocation(132,200);
                h.setLocation(102,200);
           }
       }
       //end isTouching teleport wall
       
       //power up
       //if the big ball is eaten by pacman, then ghosts will turn blue & be 
       //edible by pacman.
       if(powerUp){ 
            ghostTimer.startTimer();
            if(ghostTimer.getTime()>=525){
             setGhostImage();
            }
            if(ghostTimer.getTime()>526){
              ghostTimer.stopTimer();
              powerUp=false;
            }
       }
       if(powerUp)
       {
            ghostTimer.startTimer();
            if(ghostTimer.getTime()>=525)
            {
             setGhostImage();
            }
            if(ghostTimer.getTime()>526)
            {
              ghostTimer.stopTimer();
              powerUp=false;
            }
       }
       //end powerup
       
       //ball timer
       if(ballTimerStarted){
           ballSoundTimer.startTimer();
        }
       if(ballSoundTimer.getTime()==60){
            ballSoundTimer.stopTimer();
            ballTimerStarted=false;
        }
        //end ball timer
        
        //intersecting balls
        //pacman eats the balls and gamewincount increases, balls are removed from screen, 
        //and ball count is increased along with the score
       if(catcher.returnIntersectingBalls()!=null&&!gameOver)
       {
           if(ballSoundTimer.getTime()==0)
           {
               Greenfoot.playSound("pacman_chomp.wav");
               ballTimerStarted=true;
            }
           gameWinCount++;
            getWorld().removeObject((ball)(catcher.returnIntersectingBalls()));
            ballCount++;
            setScore(ballCount);
       }
       if(catcher.returnIntersectingBigBall()!=null&&!gameOver)
       {
           ghostTimer.stopTimer();
            getWorld().removeObjects(getWorld().getObjectsAt(this.getX(),this.getY(),bigball.class));
            powerUp=true;
            this.getredGhost().setImage("deadghost.jpg");
            this.getpinkGhost().setImage("deadghost.jpg");
            this.getblueGhost().setImage("deadghost.jpg");
            this.getorangeGhost().setImage("deadghost.jpg");
       }
       //end intersecting balls
       
       //intersecting fruit
       if(catcher.returnIntersectingFruit()!=null&&!gameOver)
       {
           Greenfoot.playSound("pacman_eatfruit.wav");
            getWorld().removeObject((fruit)(catcher.returnIntersectingFruit()));
            ballCount+=10;
            setScore(ballCount);
       }
       //intersecting fruit
       
       //intersecting ghosts
       //when the ghosts intersect w/pacman - take away a life. When 3/3 lives lost-
       //game over
       if(catcher.returnIntersectingRedGhost()!=null&&!powerUp&&!gameOver)
       {
           Greenfoot.playSound("pacman_death.wav");
            if(livesLeft==1)
            getWorld().removeObjects(getWorld().getObjectsAt(13,104,life.class));
            if(livesLeft==2)
            getWorld().removeObjects(getWorld().getObjectsAt(39,104,life.class));
            if(livesLeft==3)
            getWorld().removeObjects(getWorld().getObjectsAt(66,104,life.class));
            if(livesLeft==0)
            getWorld().removeObjects(getWorld().getObjectsAt(13,104,life.class));
            livesLeft--;
            this.setLocation(117,199);
            catcher.setLocation(117,199);
            e.setLocation(118,186);
            f.setLocation(118,214);
            g.setLocation(132,200);
            h.setLocation(102,200);
       }  
       if(catcher.returnIntersectingPinkGhost()!=null&&!powerUp&&!gameOver)
       {
           Greenfoot.playSound("pacman_death.wav");
            if(livesLeft==1)
            getWorld().removeObjects(getWorld().getObjectsAt(13,104,life.class));
            if(livesLeft==2)
            getWorld().removeObjects(getWorld().getObjectsAt(39,104,life.class));
            if(livesLeft==3)
            getWorld().removeObjects(getWorld().getObjectsAt(66,104,life.class));
            if(livesLeft==0)
            getWorld().removeObjects(getWorld().getObjectsAt(13,104,life.class));
            livesLeft--;
            this.setLocation(117,199);
            catcher.setLocation(117,199);
            e.setLocation(118,186);
            f.setLocation(118,214);
            g.setLocation(132,200);
            h.setLocation(102,200);
       }  
        if(catcher.returnIntersectingBlueGhost()!=null&&!powerUp&&!gameOver)
       {
           Greenfoot.playSound("pacman_death.wav");
            if(livesLeft==1)
            getWorld().removeObjects(getWorld().getObjectsAt(13,104,life.class));
            if(livesLeft==2)
            getWorld().removeObjects(getWorld().getObjectsAt(39,104,life.class));
            if(livesLeft==3)
            getWorld().removeObjects(getWorld().getObjectsAt(66,104,life.class));
            if(livesLeft==0)
            getWorld().removeObjects(getWorld().getObjectsAt(13,104,life.class));
            livesLeft--;
            this.setLocation(117,199);
            catcher.setLocation(117,199);
            e.setLocation(118,186);
            f.setLocation(118,214);
            g.setLocation(132,200);
            h.setLocation(102,200);
       }  
        if(catcher.returnIntersectingOrangeGhost()!=null&&!powerUp&&!gameOver)
       {
           Greenfoot.playSound("pacman_death.wav");
            if(livesLeft==1)
            getWorld().removeObjects(getWorld().getObjectsAt(13,104,life.class));
            if(livesLeft==2)
            getWorld().removeObjects(getWorld().getObjectsAt(39,104,life.class));
            if(livesLeft==3)
            getWorld().removeObjects(getWorld().getObjectsAt(66,104,life.class));
            if(livesLeft==0)
            getWorld().removeObjects(getWorld().getObjectsAt(13,104,life.class));
            livesLeft--;
            this.setLocation(117,199);
            catcher.setLocation(117,199);
            e.setLocation(118,186);
            f.setLocation(118,214);
            g.setLocation(132,200);
            h.setLocation(102,200);
       }  
       if(catcher.returnIntersectingRedGhost()!=null&&powerUp&&!gameOver)
       {
           Greenfoot.playSound("pacman_eatghost.wav");
           getWorld().removeObjects(getWorld().getObjectsAt(this.getX(),this.getY(),redGhost.class));
           redGhostRespawnTimer.startTimer();
           ballCount+=10;
           setScore(ballCount);
       }
       if(catcher.returnIntersectingPinkGhost()!=null&&powerUp&&!gameOver)
       {
           Greenfoot.playSound("pacman_eatghost.wav");
           getWorld().removeObjects(getWorld().getObjectsAt(this.getX(),this.getY(),pinkGhost.class));
           pinkGhostRespawnTimer.startTimer();
           ballCount+=10;
           setScore(ballCount);
        }
       if(catcher.returnIntersectingBlueGhost()!=null&&powerUp&&!gameOver)
       {
           Greenfoot.playSound("pacman_eatghost.wav");
           getWorld().removeObjects(getWorld().getObjectsAt(this.getX(),this.getY(),blueGhost.class));
           blueGhostRespawnTimer.startTimer();
           ballCount+=10;
           setScore(ballCount);
       }
       if(catcher.returnIntersectingOrangeGhost()!=null&&powerUp&&!gameOver)
       {
           Greenfoot.playSound("pacman_eatghost.wav");
           getWorld().removeObjects(getWorld().getObjectsAt(this.getX(),this.getY(),orangeGhost.class));
           orangeGhostRespawnTimer.startTimer();
           ballCount+=10;
           setScore(ballCount);
       }
       //end intersecting ghosts
       }
      
    
    //ghosts
    public void setGhostImage(){
        this.getredGhost().setImage("redghost.jpg");
        this.getpinkGhost().setImage("pinkghost.jpg");
        this.getblueGhost().setImage("blueghost.jpg");
        this.getorangeGhost().setImage("orangeghost.jpg");
    }
    public redGhost getredGhost(){
        return red;
    }
    public pinkGhost getpinkGhost(){
        return pink;
    }
    public blueGhost getblueGhost(){
        return blue;
    }
    public orangeGhost getorangeGhost(){
        return orange;
    }
    //end ghost methods
    
    
    //boundaries
    public boundary getUpperBound(){
        return e;
    }
    public boundary getLowerBound(){
        return f;
    }
    public boundary getRightBound(){
        return g;
    }
    public boundary getLeftBound(){
        return h;
    }
    //end bondaries
        
    //score
    public void setScore(int count)
    {
        if(count<10){
            this.getscore10().setImage(count+".JPG");
        }
        if(count>10&&count<100){
            this.getscore10().setImage(count%10+".JPG");
            this.getscore100().setImage(count/10+".JPG");
        }
        if(count>100&&count<1000){
            this.getscore10().setImage(count%10+".JPG");
            this.getscore100().setImage((count%100)/10+".JPG");
            this.getscore1000().setImage(count/100+".JPG");
        }
    }
    public score1 getscore1(){
        return score1;
    }
    public score10 getscore10(){
        return score10;
    }
    public score100 getscore100(){
        return score100;
    }
    public score1000 getscore1000(){
        return score1000;
    }
    //end score
    
    //high score
    public int getHighScore(){
        return highScore;
    }
    public score1 getHighScore1()
    {
        return highScore1;
    }
    public score10 getHighScore10()
    {
        return highScore10;
    }
    public score100 getHighScore100()
    {
        return highScore100;
    }
    public score1000 getHighScore1000()
    {
        return highScore1000;
    }
    public void setHighScore(int count){
        if(count<10){
            this.getHighScore10().setImage(count+".JPG");
        }
        if(count>10&&count<100){
            this.getHighScore10().setImage(count%10+".JPG");
            this.getHighScore100().setImage(count/10+".JPG");
        }
        if(count>100&&count<1000){
            this.getHighScore10().setImage(count%10+".JPG");
            this.getHighScore100().setImage((count%100)/10+".JPG");
            this.getHighScore1000().setImage(count/100+".JPG");
        }
    }
    //end high score
    
    
    //lives - pacman starts with 3 lives 
    public life getLife1(){ 
        return life1;
    }
    public life getLife2(){
        return life2;
    }
    public life getLife3(){
        return life3;
    }
    //end lives
    
    //fruit - 2 cherries on the board 
    public fruit getFruit1()
    {
        return fruit1;
    }
    public fruit getFruit2()
    {
        return fruit2;
    }
    //end fruit
    
    //big balls - 4 on board
    public bigball getBigBall1(){
        return bigball1;
    }
    public bigball getBigBall2(){
        return bigball2;
    }
    public bigball getBigBall3(){
        return bigball3;
    }
    public bigball getBigBall4(){
        return bigball4;
    }
    //end big balls
    
    //catcher 
    public pacmancatcher getPacManCatcher(){
      return catcher;        
    }
    //end catcher
}
