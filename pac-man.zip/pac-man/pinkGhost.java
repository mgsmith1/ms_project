import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class pinkGhost here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class pinkGhost extends Actor
{
    boolean[] inters = new boolean[19];
     int teleportCount=0;
    public void act() 
    {
        //The ghost does not move around the board randomly but instead has
        //a specific route that it takes 
        
        //starting position - in box
       if(this.isTouching(teleportWall.class))
        {
           teleportCount++;
           if(teleportCount%2==1)
           {
            this.setLocation(495,200);
           }
           if(teleportCount%2==0)
           {
           this.setLocation(117,199);
            }
       }
       //move to middle position
         if(getX()!=300&&inters[18]==false){
         moveRight();   
        }
        else if(getX()==300&&inters[18]==false){
         inters[18]=true;
        }
       //0
        else if(getY()!=160&&inters[0]==false){
         moveUp();   
        }
        else if(getY()==160&&inters[0]==false){
         inters[0]=true;
        }
        //1
        else if(getX()!=324&&inters[1]==false){
            moveRight();
        }
        else if(getX()==324&&inters[1]==false){
            inters[1]=true;
        }
        //2
        else if(getY()!=121&&inters[2]==false){
            moveUp();
        }
       else if(getY()==121&&inters[2]==false){
            inters[2]=true;
        }
        //3
       else if(getX()!=367&&inters[3]==false){
            moveRight();
        }
        else if(getX()==367&&inters[3]==false){
            inters[3]=true;
        }
        //4
         else if(getY()!=82&&inters[4]==false){
            moveUp();
        }
         else if(getY()==82&&inters[4]==false){
            inters[4]=true;
        } 
        //5
         else if(getX()!=413&&inters[5]==false){
            moveRight();
        }
         else if(getX()==413&&inters[5]==false){
            inters[5]=true;
        }
        //6
         else if(getY()!=126&&inters[6]==false){
            moveDown();
        }
         else if(getY()==126&&inters[6]==false){
            inters[6]=true;
        } 
        //7
         else if(getX()!=489&&inters[7]==false){
            moveRight();
        }
         else if(getX()==489&&inters[7]==false){
            inters[7]=true;
        }
        //8
         else if(getY()!=32&&inters[8]==false){
            moveUp();
        }
         else if(getY()==32&&inters[8]==false){
            inters[8]=true;
        }
        //9
         else if(getX()!=320&&inters[9]==false){
            moveLeft();
        }
         else if(getX()==320&&inters[9]==false){
            inters[9]=true;
        }
        //10
         else if(getY()!=82&&inters[10]==false){
            moveDown();
        }
         else if(getY()==82&&inters[10]==false){
            inters[10]=true;
        }
        //11
         else if(getX()!=113&&inters[11]==false){
            moveLeft();
        }
         else if(getX()==113&&inters[11]==false){
            inters[11]=true;
        }
        //12
         else if(getY()!=120&&inters[12]==false){
            moveDown();
        }
         else if(getY()==120&&inters[12]==false){
            inters[12]=true;
        }
        //13
         else if(getX()!=187&&inters[13]==false){
            moveRight();
        }
         else if(getX()==187&&inters[13]==false){
            inters[13]=true;
        }
        //14
         else if(getY()!=199&&inters[14]==false){
            moveDown();
        }
         else if(getY()==199&&inters[14]==false){
            inters[14]=true;
        }
        //15
         else if(getX()!=370&&inters[15]==false){
            moveLeft();
        }
         else if(getX()==370&&inters[15]==false){
            inters[15]=true;
        }
        //16
         else if(getY()!=160&&inters[16]==false){
            moveUp();
        }
         else if(getY()==160&&inters[16]==false){
            inters[16]=true;
        }
        //17
         else if(getX()!=324&&inters[17]==false){
            moveLeft();
        }
         else if(getX()==324&&inters[17]==false){
            inters[17]=true;
            for(int i=1;i<inters.length-1;i++)
            {
                inters[i]=false;
            }
        }
    }
    public void moveLeft(){
           move(-1);
    }
    public void moveRight(){
           setRotation(0);
           move(1);
    }
    public void moveUp(){
           setLocation(getX(),getY()-1);
    }
    public void moveDown(){
           setLocation(getX(),getY()+1);
    } 
}
