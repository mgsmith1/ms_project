import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class boundary here.
 * 
 * @author makenna
 * @version (a version number or a date)
 */
public class boundary extends Actor
{
    public boolean getIsTouching()
    {
     if(isTouching(wall.class)||isTouching(smallwall.class))
     {
      return true;   
     }
     return false;
    } 
}
